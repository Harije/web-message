# Sample PHP WebSocket Server Built with Ratchet

This scaffold will allow you to create a WebSocket server in your PHP environment. View the tutorial ["How to Create a WebSocket Server in PHP to Build a Real-Time Application"](https://www.twilio.com/php) for additional information and context.
